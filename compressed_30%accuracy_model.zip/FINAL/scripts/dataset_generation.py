import pandas as pd
import numpy as np
from Crypto.Cipher import AES, DES, DES3
from Crypto.Random import get_random_bytes
import base64
from scipy.stats import entropy

def byte_distribution(ciphertext):
    """Calculate the byte frequency distribution of the ciphertext."""
    freq = [ciphertext.count(byte) / len(ciphertext) for byte in range(256)]
    return freq

def generate_features(message, algorithm):
    if algorithm == 'AES':
        cipher = AES.new(get_random_bytes(16), AES.MODE_ECB)
    elif algorithm == 'DES':
        cipher = DES.new(get_random_bytes(8), DES.MODE_ECB)
    else:  # 3DES
        cipher = DES3.new(get_random_bytes(16), DES3.MODE_ECB)

    encrypted_message = cipher.encrypt(message)
    encrypted_message_base64 = base64.b64encode(encrypted_message).decode('utf-8')
    
    length = len(encrypted_message_base64)
    freq_distribution = byte_distribution(encrypted_message)
    entropy_value = entropy(freq_distribution)
    std_dev = np.std(list(encrypted_message))
    
    return [length, entropy_value, std_dev, algorithm]

def generate_dataset(num_samples=2000):
    algorithms = ['AES', 'DES', '3DES']
    data = []

    for _ in range(num_samples):
        message = get_random_bytes(16)
        for algo in algorithms:
            features = generate_features(message, algo)
            data.append(features)
    df = pd.DataFrame(data, columns=['Length', 'Entropy', 'StdDev', 'Algorithm'])
    df.to_csv('C:/Users/priya/Documents/SIH_JAYY/FINAL/data/deep.csv', index=False)


if __name__ == '__main__':
  generate_dataset()
