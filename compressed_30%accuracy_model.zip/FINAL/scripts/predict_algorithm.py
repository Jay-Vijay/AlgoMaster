def predict_algorithm(ciphertext_hex):
    ciphertext = bytes.fromhex(ciphertext_hex)
    length = len(ciphertext)
    entropy = -np.sum([p * np.log2(p) for p in np.bincount(np.frombuffer(ciphertext, dtype=np.uint8))/len(ciphertext) if p > 0])
    features = [[length, entropy]]
    
    # Load models
    rf_model = joblib.load('Best_RandomForest_model.pkl')
    svm_model = joblib.load('SVM_model.pkl')
    gb_model = joblib.load('GradientBoosting_model.pkl')
    
    # Predictions
    predictions = {
        'RandomForest': rf_model.predict(features)[0],
        'SVM': svm_model.predict(features)[0],
        'GradientBoosting': gb_model.predict(features)[0]
    }
    
    # Combine predictions or choose based on confidence
    final_prediction = max(predictions, key=lambda k: predictions[k])
    return le.inverse_transform([final_prediction])[0]

# Test the pipeline
print(predict_algorithm('your_ciphertext_here'))
