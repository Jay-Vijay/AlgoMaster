import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import joblib

# Load dataset
df = pd.read_csv('C:/Users/priya/Documents/SIH_JAYY/FINAL/data/deep.csv')

# Encode labels
X = df[['Length', 'Entropy', 'StdDev']]
le = LabelEncoder()
y = le.fit_transform(df['Algorithm'])

# Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define models with hyperparameter tuning
param_grid_rf = {
    'n_estimators': [100, 200, 500],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

param_grid_svm = {
    'C': [0.1, 1, 10],
    'gamma': [1, 0.1, 0.01],
    'kernel': ['rbf', 'linear']
}

param_grid_gb = {
    'n_estimators': [100, 200, 500],
    'learning_rate': [0.01, 0.1, 0.2],
    'max_depth': [3, 5, 10]
}

models = {
    'RandomForest': GridSearchCV(RandomForestClassifier(random_state=42), param_grid_rf, cv=5, n_jobs=-1),
    'SVM': GridSearchCV(SVC(probability=True), param_grid_svm, cv=5, n_jobs=-1),
    'GradientBoosting': GridSearchCV(GradientBoostingClassifier(random_state=42), param_grid_gb, cv=5, n_jobs=-1)
}

trained_models = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    best_model = model.best_estimator_
    y_pred = best_model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f'{name} Best Model Accuracy: {accuracy:.2f}')
    trained_models[name] = best_model
    joblib.dump(best_model, f'C:/Users/priya/Documents/SIH_JAYY/FINAL/model1/{name}_model.pkl')  # Save the model

# Save the best model overall
best_rf = trained_models['RandomForest']
joblib.dump(best_rf, 'C:/Users/priya/Documents/SIH_JAYY/FINAL/model1/Best_RandomForest_model.pkl')
